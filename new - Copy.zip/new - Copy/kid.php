<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
    /* border-collapse: separate;
    border-spacing: 0 10px; /* Adjust the second value to change the vertical spacing between rows */
    width: 100%; 
    border: none;
  }

  td {
    padding: 10px; /* Adjust as needed */
    /* border: 1px solid #dddddd; */
    text-align: left;
  }

  img {
    max-width: 100%;
    height: 200px;
  }
  .td
  {
    
    font-size: 30px;
    font-weight: bold;
  
  }
    </style>
</head>
<body>
   <h2 align="center"> Kids' Rides and Shows</h2> 
   <hr color="green" size="10px" width="100%">
   <br>
   <h2 align="center">Top-Rated Kids Rides</h2>
   <br>
  <center> <h4>Let memories unfold the story of your childhood while you witness your little ones having a gala of a time. Kids' attractions at the best amusement park for kids Imagicaa <br> offer joyful rides for every kid in town.</h4></center>
   <br>
   <table>
  <tr>
   <td><img src="k1.jpg" alt="Chhota Bheem The Ride"></td>
    <td><img src="k2.webp" alt="Alibaba Aur Chalis Chorr"></td>
    <td><img src="k3.webp" alt="Bump It Boats"></td>
    
  </tr>
  <tr class="td">
    <td>Chhota Bheem The Ride</td>
    <td>Happy Wheels</td>
    <td>Humpty's Fall</td>
  </tr>
  <tr>
    <td>The Stars of Theme park have created a special roller<br> coaster, welcoming chhota Bheem and his friends. </td>
    <td>Fun driving School for kids!</td>
    <td>Experience this mini drop ride; an evergreen for kids</td>
  </tr>

  <tr>
    <td><img src="k4.webp" alt="Alibaba Aur Chalis Chorr"></td>
    <td><img src="k5.webp" alt="Bump It Boats"></td>
    <td><img src="k6.webp" alt="Chhota Bheem The Ride"></td>
  </tr>
  <tr class="td">
    <td>Loch Ness Expplores</td>
    <td>The Magic Carousel</td>
    <td>Tubby Takes off</td>
  </tr>
  <tr>
    <td>The Loch Ness monster has finally made an <br> apperance to create fun splashes on this stream!</td>
    <td>Gallop smoothly aboard this classic entertainer!</td>
    <td> Get on board this fun merry-go-round with <br> Theme park favourite charater</td>
  </tr>

  <tr>
    <td><img src="k7.webp" alt="Alibaba Aur Chalis Chorr"></td>
  </tr>
  <tr class="td">
    <td>Wagon-O-O-Wheel</td>
  </tr>
  <tr>
    <td> Round-n-round mini ferris wheel for kids</td>
  </tr>
</table>
</body>
</html>