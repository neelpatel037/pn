

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Registration</title>
    <link rel="stylesheet" href="st.css">
</head>
<body>

    <div class="container">
        <div class="form-container">
            <h2 align="center">Admin</h2>
            <form action="admlog.php" method="POST" align="center">
                <input type="text" name="username" placeholder="Username" required><br>
                <input type="password" name="password" placeholder="Password" required><br>
                <button type="submit" name="login">Login</button>
            </form>
            
        </div>
    </div>

</body>
</html>

<?php
// @include 'conect.php';
// if(isset($_POST["login"]))
// {
    

//     $username = $_POST['username'];
//     $password = $_POST['password'];

//     $sql = "SELECT * FROM `users` WHERE `username` = '$username' AND `password` = '$password'";
//     $result = mysqli_query($conn, $sql);

//     if(mysqli_num_rows($result) > 0)
//     {
//         header("location: adm.php");
//         exit();
//     }
//     else
//     {
//         echo "<script>alert('Invalid username or password')</script>";
//     }
// }
?>
<?php
// Start session (if not already started)
session_start();

// Include database connection file
include_once 'conect.php';

if (isset($_POST["login"])) {
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare a select statement
    $sql = "SELECT * FROM users WHERE username = p1@23 AND password = 150 ";
    
    if ($stmt = mysqli_prepare($conn, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);

        // Set parameters
        $param_username = $username;
        $param_password = $password;

        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            // Store result
            mysqli_stmt_store_result($stmt);

            // Check if username and password exist, if yes then redirect to admin page
            if (mysqli_stmt_num_rows($stmt) == 1) {
                $_SESSION['username'] = $username; // Store username in session variable
                header("location: adm.php");
                exit();
            } else {
                echo "<script>alert('Invalid username or password')</script>";
            }
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($conn);
}
?>
