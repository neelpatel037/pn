<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
    /* border-collapse: separate;
    border-spacing: 0 10px; /* Adjust the second value to change the vertical spacing between rows */
    width: 100%; 
    border: none;
  }

  td {
    padding: 10px; /* Adjust as needed */
    /* border: 1px solid #dddddd; */
    text-align: left;
  }

  img {
    max-width: 100%;
    height: 200px;
  }
  .td
  {
    
    font-size: 30px;
    font-weight: bold;
  
  }
    </style>
</head>
<body>
   <h2 align="center"> ROLLER COASTER YOUR WAY TO HAPPINESS AND THRILLING WILD TIME</h2> 
   <hr color="green" size="10px" width="100%">
   <br>
   <h2 align="center">Ultimate Roller Coaster Thrill Rides Await. Theme Park</h2>
   <br>
  <center> <h4>Are you ready to have your world turned upside down in the most adventurous way? Roller coasters are the best way to experience this in the safest of the environment!<br> In a controlled manner, you set out on a ride that is full of unexpected twists and turns with a change in speed that will have more than just butterflies <br>in your stomach!
  <br></h4>

<br>
   <table>
  <tr>
   <td><img src="r1.webp" alt="Chhota Bheem The Ride"></td>
    <td><img src="r2.jpg" alt="Alibaba Aur Chalis Chorr"></td>
    <td><img src="r3.webp" alt="Bump It Boats"></td>
    
  </tr>
  <tr class="td">
    <td>India's Baddest & Fastest Roller Coaster Ride</td>
    <td>Explore Space with this Roller Coaster ride</td>
    <td>Ride Back In Time To The Wild Wild West Era</td>
  </tr>
  <tr>
    <td>Get your adrenaline pumping with excitement in just 150s by zipping across in the fatest,tallest and floorless roller coaster <b>-NITRO </td>
    <td>To the Moon & Back! Set out on the ultimate space exploration thrill on india's only indoor dark roller coaster,<b> DEEP SPACE</td>
    <td>Go back in time to uncover the framsteads & gold mines of the wild west Era with <b> GOLD RUSH EXPRESS </b> roller coaster ride</td>
  </tr>

  <tr>
    <td><img src="r4.jpg" alt="Alibaba Aur Chalis Chorr"></td>
    <td><img src="r5.webp" alt="Bump It Boats"></td>
    <td><img src="r6.jpg" alt="Chhota Bheem The Ride"></td>
  </tr>
  <tr class="td">
    <td> A joy Ride Through The Universe of Dholakpur </td>
    <td>Gear up for an etreme thrill adventure.</td>
    <td>This thrill ride is surely for the crazy ones</td>
  </tr>
  <tr>
    <td> Discover the Dholakpur universe and roller coaster your way to your 'Junior's Happiness' aboard <b>Chhota Bheem-The Ride</td>
    <td>This ride will shoot you like a rocket in the sky in a matter of seconds. Exeperience a total free fall from the height of 132 feet with <b> DARE 2 DROP </td>
    <td> If you are looking for absolute disorientation, get seated The <b> Scream Machine </b> first gathers some momentum by spinning.</td>
  </tr>

  
</table>
</body>
</html>