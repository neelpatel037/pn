 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .h1
        {
            font-size: 30px;
            text-align: center;
            font-family: Bold;
        }
        p
        {
            
           margin-left:100px ;
           font-size: 25px;
        }
        li
        {
            
           margin-left:100px ;
           font-size: 25px;
        }
        .img
        {
         max-width: 100%;
         height: 700px;
        }
        h1
        {
         margin-left: 100px;
         fontab-size: 35px;
        }        
    </style>
 </head>
 <body>
    <h1 class="h1" >About Theme Park</h1>

    <hr color="orange" width="80%" size="10px">

    <center><h2 >India's favourite themed entertainment destination</h2></center>

    <p> Theme Park is a themed entertainment destination featuring multiple themed experiences, an on-premise hotel, unique characters, innovative and unique attractions, thrilling rides and shows, meeting spaces, and major events - it's a place for all seasons, <br>all interests, and all ages.</p>
    
    <center><img class="img" src="map.jpg" alt="" ></img></center>

    <p>India's first and only family holiday destination from Gujrat and Botad, Theme Park is the perfect weekend getaway which <br>includes an International   Standard theme park, and a premium hotel.</p>
   
   <p>At  Theme Park, guests can bump into the in-house characters of Tubbby – The Elephant, Roberto – The Star Chef, The Lost <br>Astronaut, Mogambo of Mr. India fame and The Gingerbread Man while hopping from one ride to another.</p> 
  
   <h1>Purpose and Goals </h1>
   <hr color="black" width="90%" size="7px">
   <p>Our ultimate goal is to transport our guests to a world of wonder, where imagination knows no bounds and adventure awaits at every <br>turn. We aim to create a safe and inclusive environment where families can come together to laugh, play, and make cherished memories. <br>Through our dedication to excellence in theming, rides, entertainment, and dining, we seek to be a leader in the theme park industry and <br> a beloved destination for generations to come.</p>
    
   <h1>Offerings </h1>
   <hr color="black" width="90%" size="7px">
   <p>Immersive Theming: Our theme park transports you to a world of wonder with meticulously designed environments and immersive theming. From enchanted forests to futuristic cities, every corner of our park is filled with magic and excitement.
      <br><br>
      

Thrilling Rides: Experience adrenaline-pumping thrills on our world-class roller coasters, water rides, and attractions. Whether you're a thrill-seeker or a family looking for fun, we have rides for all ages and preferences.
<br><br>

Interactive Experiences: Step into the action with our interactive experiences and themed walkthrough attractions. Solve mysteries, embark on epic quests, and make unforgettable memories with your friends and family.
<br><br>
Family-Friendly Fun: Our park is designed with families in mind, offering a wide range of attractions and entertainment options suitable for guests of all ages. From kiddie rides and play areas to character meet-and-greets, there's something for everyone to enjoy.
<br><br>
Delicious Dining: Take a break from the excitement and refuel at our diverse dining options. From themed restaurants serving up gourmet meals to snack carts offering tasty treats, there's no shortage of delicious food to satisfy your cravings.</p>

<h1>Customer Opinions </h1>
   <hr color="black" width="90%" size="7px">
   <p>"Our family had the most amazing time at the theme park! The theming was so detailed and realistic, the rides were thrilling, and <br> the live shows were truly mesmerizing. We can't wait to come back again next year!" - The Makwana Family</p>

   <h1>Achievements </h1>
   <hr color="black" width="90%" size="7px">
   <ul>
  <li>Voted Best Theme Park of the Year for three consecutive years</li>
  <li>Recognized for Excellence in Theming and Entertainment</li>
  <li>Awarded for Innovation in Ride Design and Guest Experience</li>
</ul>

</body>
 </html>